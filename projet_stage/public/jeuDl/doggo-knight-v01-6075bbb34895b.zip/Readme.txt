This game is copyrighted ©.

All Rights Reserved.
Feel free to report any bug you'll find to me on Itch.io (comment section).
The OST is available here: https://www.youtube.com/watch?v=3sq2qLlEJvY